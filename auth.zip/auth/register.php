<?php
include "../config/koneksi.php";

$username = $_POST['username'];
$email    = $_POST['email'];
$password = hash('sha256', $_POST['password']);
$no_hp    = $_POST['no_hp'];

$query = mysqli_query($conn,
    "INSERT INTO admin (username, email, password, no_hp)
     VALUES ('$username','$email','$password','$no_hp')"
);

if ($query) {
    echo json_encode([
        "status" => "success",
        "message" => "Registrasi berhasil"
    ]);
} else {
    echo json_encode([
        "status" => "failed",
        "message" => "Registrasi gagal"
    ]);
}
?>
