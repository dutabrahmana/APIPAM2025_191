<?php
include "../config/koneksi.php";

$username = $_POST['username'];
$password = hash('sha256', $_POST['password']);

$query = mysqli_query($conn,
    "SELECT id_admin, username, email 
     FROM admin 
     WHERE username='$username' AND password='$password'"
);

if (mysqli_num_rows($query) > 0) {
    echo json_encode([
        "status" => "success",
        "message" => "Login berhasil"
    ]);
} else {
    echo json_encode([
        "status" => "failed",
        "message" => "Username atau password salah"
    ]);
}
?>
